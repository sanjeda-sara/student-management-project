Simple Student Management System

Part/panel of Application:

Website
Admin Panel
Student Panel
Teacher Panel 

Feature list of each part/panel:
Website
	Home Page
		Menu Section
		Course List with Teacher info	
		Subscriber Section
		Notice Section
		A Footer Section
	Couser Detail
		Individual course detail info 
	Login Page
		Login Form
	Registration Page
		Registration Form
		Confirmation email
===================================
Admin Panel:
	Login & logout system
		
	Create create and manage teacher
	Admin manage teacher course
	Admin manage student registration
	Confirmation email
===================================
Teacher Panel
	Login / logout system
	Teacher create, update course
	Teacher can see his or her published course
	Teacher can see enrolled student
===================================
Student Panel
	Login / logout system
	Student can see total apply couse
	Student can see total approved couse


Feature Of Our Simple Project

- A Website that contain different course info dynamically.
- Student can see detail specific course info.

- Student can enrolled courses.
- Student will atuo register & email notified when he enrolled a course.
- Student can not enrolled same course twice.
- student can login.
- Student have dashboard which show all enrolled course with status.
- Student cand update profile.
- Student can change password.
- Student can register.

- Admin uesr can login.
- admin user create & manage new admin user.
- Amin user create & Manage teacher info.
- Admin user cna see detail course that is created by teacher.
- Admin use rcan change the course status.
- Admin user can active or inactive student status.
- Admin user can see the student enrolled course info.
- Admin user can confirm/denay student enrolled status.

- Teacher use can login.
- Teacher user create & mange course.
- Teacher can not delete ative course info.
- Teacher user can see his/her approved course.
- Teacher can see enrolled student info of his/her published couse.


Full free student ship
		
	

	
	
