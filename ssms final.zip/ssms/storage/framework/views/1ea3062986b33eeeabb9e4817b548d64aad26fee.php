<?php $__env->startSection('title'); ?>
    Home page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1 class="text-center">All Courses</h1>
                    <div class="row mt-4">
                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <a href="<?php echo e(route('subject-details', ['id' => $subject->id])); ?>" class="nav-link">
                                    <div class="card">
                                        <img src="<?php echo e(asset($subject->image)); ?>" alt="" class="card-img-top" style="height: 250px">
                                        <div class="card-body">
                                            <h2 class="card-title text-dark" style="font-size: 20px;"><?php echo e($subject->title); ?></h2>
                                            <p style="text-align: justify; font-size: 16px;" class="text-dark" ><?php echo e($subject->short_description); ?></p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ssms\resources\views/front/home/home.blade.php ENDPATH**/ ?>