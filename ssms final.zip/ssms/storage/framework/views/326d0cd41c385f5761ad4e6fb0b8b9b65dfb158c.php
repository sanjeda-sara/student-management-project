<!-- ========== Left Sidebar Start ========== -->
<div class="vertical-menu">

    <div data-simplebar class="h-100">

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li>
                    <a href="<?php echo e(route('dashboard')); ?>" class="waves-effect">
                        <i class="bx bx-home-circle"></i><span class="badge badge-pill badge-info float-right">03</span>
                        <span>Dashboard</span>
                    </a>
                </li>
                <?php if(Auth::check() && Auth::user()->role == 'admin'): ?>
                    <li class="menu-title">Admin Module</li>

                    <li>
                        <a href="javascript:void(0);" class="has-arrow waves-effect">
                            <i class="bx bx-layout"></i>
                            <span>User Module</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <li><a href="<?php echo e(route('create-user')); ?>">Create User</a></li>
                            <li><a href="<?php echo e(route('manage-user')); ?>">Manage User</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="bx bx-layout"></i>
                            <span>Role</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <li><a href="<?php echo e(route('create-role')); ?>">Create Role</a></li>
                            <li><a href="">Manage Role</a></li>
                        </ul>
                    </li>

                    <li>
                        <a href="<?php echo e(route('manage-enroll')); ?>" class="waves-effect">
                            <i class="bx bx-home-circle"></i><span class="badge badge-pill badge-info float-right">03</span>
                            <span>Manage Enroll</span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if(Auth::check() && (Auth::user()->role == 'admin' || Auth::user()->role == 'teacher')): ?>
                    <li class="menu-title">Teacher Module</li>
                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="bx bx-layout"></i>
                            <span>Teacher</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <?php if(Auth::user()->role == 'teacher'): ?>
                                <li><a href="<?php echo e(route('create-profile')); ?>">Create Profile</a></li>
                            <?php endif; ?>
                            <?php if(Auth::user()->role == 'admin'): ?>
                                <li><a href="<?php echo e(route('manage-profile')); ?>">Manage Profile</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="bx bx-layout"></i>
                            <span>Subject</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <?php if(Auth::user()->role == 'teacher'): ?>
                                <li><a href="<?php echo e(route('create-subject')); ?>">Create Subject</a></li>
                            <?php endif; ?>
                            <li><a href="<?php echo e(route('manage-subject')); ?>">Manage Subject</a></li>
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if(Auth::check() && (Auth::user()->role == 'admin' || Auth::user()->role == 'user')): ?>
                    <li class="menu-title">Student Module</li>

                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="bx bx-store"></i>
                            <span>Student Info</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <?php if(Auth::user()->role == 'user'): ?>
                                <li><a href="<?php echo e(route('create-student-info')); ?>">Add Student Info</a></li>
                            <?php endif; ?>
                            <?php if(Auth::user()->role == 'admin'): ?>
                                <li><a href="<?php echo e(route('manage-student-info')); ?>">Manage Student Info</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div>
<!-- Left Sidebar End -->
<?php /**PATH C:\xampp\htdocs\ssms\resources\views/admin/includes/menu.blade.php ENDPATH**/ ?>