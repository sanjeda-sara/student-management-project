<?php $__env->startSection('title'); ?>
    Manage Subject
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Manage Subject</h4>
                    </div>
                    <div class="card-body">
                        <table class="table" id="dataTable">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Teacher Name</th>
                                <th>Title</th>
                                <th>Code</th>
                                <th>Fee</th>
                                <th>Image</th>
                                <th>Short Description</th>
                                <th>Long Description</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e(\App\Models\User::find($subject->teacher_id)->name); ?></td>
                                    <td><?php echo e($subject->title); ?></td>
                                    <td><?php echo e($subject->code); ?></td>
                                    <td><?php echo e($subject->fee); ?></td>
                                    <td>
                                        <img src="<?php echo e(asset($subject->image)); ?>" alt="" style="height: 100px; width: 100px">
                                    </td>
                                    <td><?php echo $subject->short_description; ?></td>
                                    <td><?php echo substr_replace($subject->long_description, '...', 260); ?></td>
                                    <td><?php echo e($subject->status == 1 ? 'Published' : 'Unpublished'); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('change-subject-status',['id' => $subject->id])); ?>" class="btn btn-info">status</a>
                                        <a href="<?php echo e(route('edit-subject',['id' => $subject->id])); ?>" class="btn btn-secondary">edit</a>
                                        <a href="<?php echo e(route('delete-subject',['id' => $subject->id])); ?>" onclick="return confirm('Are you sure to delete this?');" class="btn btn-danger">delete</a>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ssms\resources\views/admin/subject/manage.blade.php ENDPATH**/ ?>