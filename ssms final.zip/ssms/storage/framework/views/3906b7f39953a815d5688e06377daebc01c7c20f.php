<?php $__env->startSection('title'); ?>
    Create Role
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6 mx-auto">
                <div class="card">
                    <div class="card-header">
                        <h4>Create Role</h4>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('new-role')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <label for="" class="col-md-4 col-form-label">Role Display Name</label>
                                <div class="col-md-8">
                                    <input type="text" class="form-control" name="display_name" />
                                </div>
                            </div>
                            <div class="form-group row mt-3">
                                <label for="" class="col-md-4 col-form-label">Role Name</label>
                                <div class="col-md-8">
                                    <input type="text" class="form-control" name="name" />
                                </div>
                            </div>
                            <div class="form-group row mt-3">
                                <label for="" class="col-md-4 col-form-label"></label>
                                <div class="col-md-8">
                                    <div class="d-grid">
                                        <input type="submit" class="btn col-12 btn-success" value="Create Role" />
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ssms\resources\views/admin/role/create.blade.php ENDPATH**/ ?>