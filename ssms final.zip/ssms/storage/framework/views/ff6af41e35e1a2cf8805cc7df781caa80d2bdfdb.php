<?php $__env->startSection('title'); ?>
    Edit Enroll
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6 mx-auto">
                <div class="card">
                    <div class="card-header">
                        <h4>Edit Enroll</h4>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('update-enroll', ['id' => $enroll->id])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <label for="" class="col-md-4 col-form-label">Payment Status</label>
                                <div class="col-md-8">
                                    <label for=""><input type="radio" name="payment_status" <?php echo e($enroll->payment_status == 1 ? 'checked' : ''); ?> value="1"> Completed</label>
                                    <label for=""><input type="radio" name="payment_status" <?php echo e($enroll->payment_status == 0 ? 'checked' : ''); ?> value="0"> Pending</label>
                                </div>
                            </div>
                            <div class="form-group row mt-3">
                                <label for="" class="col-md-4 col-form-label">Enroll Status</label>
                                <div class="col-md-8">
                                    <label for=""><input type="radio" name="enroll_status" <?php echo e($enroll->enroll_status == 1 ? 'checked' : ''); ?> value="1"> Selected</label>
                                    <label for=""><input type="radio" name="enroll_status" <?php echo e($enroll->enroll_status == 0 ? 'checked' : ''); ?> value="0"> Waiting</label>
                                </div>
                            </div>
                            <div class="form-group row mt-3">
                                <label for="" class="col-md-4 col-form-label"></label>
                                <div class="col-md-8">
                                    <div class="d-grid">
                                        <input type="submit" class="btn col-12 btn-success" value="Update Enroll Info" />
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ssms\resources\views/admin/enroll/edit.blade.php ENDPATH**/ ?>