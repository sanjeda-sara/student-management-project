<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sawon.com - <?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>front/css/bootstrap.css">
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>front/css/helper.css">
</head>
<body>
<nav class="navbar navbar-expand-md bg-dark navbar-dark">
    <div class="container">
        <a href="" class="navbar-brand">Logo</a>
        <ul class="navbar-nav">
            <li class="nav-item"><a href="<?php echo e(route('home')); ?>" class="nav-link text-white">Home</a></li>
            <li class="nav-item"><a href="" class="nav-link text-white">Contact</a></li>
            <?php if(!Auth::check()): ?>
                <li class="nav-item"><a href="<?php echo e(route('user-login')); ?>" class="nav-link text-white">Login</a></li>
                <li class="nav-item"><a href="<?php echo e(route('user-register')); ?>" class="nav-link text-white">Register</a></li>
            <?php else: ?>
                <li class="nav-item"><a href="" onclick="event.preventDefault(); document.getElementById('logoutForm').submit();" class="nav-link text-white">Logout</a></li>
                <form action="<?php echo e(route('logout')); ?>" method="post" id="logoutForm">
                    <?php echo csrf_field(); ?>
                </form>
            <?php endif; ?>
        </ul>
    </div>
</nav>

<?php echo $__env->yieldContent('body'); ?>


<script src="<?php echo e(asset('/')); ?>front/js/jquery-3.6.0.min.js"></script>
<script src="<?php echo e(asset('/')); ?>front/js/bootstrap.bundle.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ssms\resources\views/front/master.blade.php ENDPATH**/ ?>