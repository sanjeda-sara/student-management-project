<?php $__env->startSection('title'); ?>
    Login Page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-6 mx-auto">

                    <div class="card m-t-100">
                        <div class="card-header">
                            <h2 class="text-center">User Login</h2>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('user-post-login')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                    <label for="" class="col-md-4 col-form-label">Email</label>
                                    <div class="col-md-8">
                                        <input type="email" class="form-control" name="email" />
                                    </div>
                                </div>
                                <div class="form-group row mt-3">
                                    <label for="" class="col-md-4 col-form-label">Password</label>
                                    <div class="col-md-8">
                                        <input type="password" class="form-control" name="password" />
                                    </div>
                                </div>
                                <div class="form-group row mt-3">
                                    <label for="" class="col-md-4 col-form-label"></label>
                                    <div class="col-md-8">
                                        <div class="d-grid">
                                            <input type="submit" class="btn col-12 btn-success" value="Login" />
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <div class="mt-3">
                                <p>Don't have an account? <a href="<?php echo e(route('user-register')); ?>">Register</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ssms\resources\views/front/auth/user-login.blade.php ENDPATH**/ ?>